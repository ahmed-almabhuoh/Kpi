@extends('layouts.admin')

@section('title', 'Title Page')

@section('style')

@endsection

@section('content')
    <h1>KPI System</h1>
@endsection

@section('script')

@endsection